import { isDataView } from "util/types"
import { Actividad } from "../data/entity/actividad"
import debug from "debug"
import db from "../db"
import { res } from "../common"

const log = debug("app:Actividad")

const getAll = () => {
    const query = "select * from tarea"

    return new Promise<Array<Actividad>>((resolve, _) => {
        db.query(query, (err, rows, fields) => {
            if (err) {
                return resolve([])
            }

            const result: Array<Actividad> = rows.map(el => {
                return {
                    id: el?.id_tarea ?? 0,
                    fecha: el?.fecha ?? "",
                    tipo: el?.tipo ?? "",
                    totalHoras: el?.totalHoras ?? 0,
                    actividad: el?.actividad ?? "",
                    observaciones: el?.observaciones ?? ""
                }
            })

            return resolve(result)
        })
    })
}

const getById = (id: number) => {
    const query = "select * from tarea where id_tarea = ?"

    return new Promise<Actividad | null>((resolve, reject) => {
        db.query(query, [id], (err, rows, fields) => {
            if (err || !rows[0])
                return resolve(null)

            const act: Actividad = {
                id: rows[0].id ?? 0,
                fecha: rows[0].fecha ?? "",
                tipo: rows[0].tipo ?? "",
                totalHoras: rows[0].totalHoras ?? 0,
                actividad: rows[0].actividad ?? "",
                observaciones: rows[0].observaciones ?? ""
            }

            return resolve(act)
        })
    })
}

const insert = (actividad: Actividad) => {
    const query = "insert into tarea values (?, ?, ?, ?, ?, ?, ?)"
    return new Promise<boolean>((resolve, reject) => {
        db.query(query, [
            null,
            actividad.actividad,
            actividad.fecha,
            actividad.tipo,
            actividad.totalHoras,
            actividad.observaciones,
            actividad.id_alumno
        ], (err, result, fields) => {
            if (err) {
                return resolve(false)
            }

            return resolve(true)
        })
    })
}

const update = (newActividad: Actividad) => {
    const query = "update tarea set actividad = ?, fecha = ?, tipo = ?, totalHoras = ?, observaciones = ? where id_tarea = ?"
    return new Promise<boolean>((resolve, reject) => {
        db.query(query, [
            newActividad.actividad,
            newActividad.fecha,
            newActividad.tipo,
            newActividad.totalHoras,
            newActividad.observaciones,
            newActividad.id,
        ], (err, rows, fields) => {

            if (err) {
                log(err)
                return resolve(false)
            }

            return resolve(true)
        })
    })
}

const remove = (id: number) => {
    const query = "delete from tarea where id_tarea = ?"
    return new Promise<boolean>((resolve, reject) => {
        db.query(query, [id], (err, rows, fields) => {
            if (err) {
                log(err)
                return resolve(false)
            }

            return resolve(true)
        })
    })
}

export const actividad = { getById, insert, update, remove, getAll }