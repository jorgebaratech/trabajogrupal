import { alumno } from "./alumno"
import { actividad } from "./actividad"
import login from "./login"
import { empresa } from "./empresa"

const services = {
    alumno, actividad, login, empresa
}

export = services