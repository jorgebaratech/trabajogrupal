import { Alumno } from '../data/entity/alumno'
import { Profesor } from '../data/entity/profesor'
import db from '../db'

const loginAlumno = (email: string, password: string) => {
    const query = "select * from alumno where correo = ? and contraseña = ?"

    return new Promise<Alumno | null>((resolve, reject) => {
        db.query(query, [email, password], (err, rows, fields) => {
            if (err || !rows[0]) {
                return resolve(null)
            }

            const alumno: Alumno = {
                id: rows[0]?.id_alumno ?? 0,
                nombre: rows[0]?.nombre ?? '',
                apellidos: rows[0]?.apellidos ?? '',
                password: rows[0]?.password ?? '',
                dni: rows[0]?.DNI ?? '',
                fechaN: rows[0].fechaN ?? '',
                correo: rows[0].correo ?? '',
                tel: rows[0].telefono ?? '',
                empresa: rows[0].id_empresa ?? 0,
                tutor: rows[0].id_profesor ?? 0,
                observaciones: rows[0].observaciones ?? '',
                horasDual: rows[0].horasDual ?? 0,
                horasFCT: rows[0].horasFCT ?? 0
            }

            return resolve(alumno)
        })
    })
}

const loginProfesor = (email: string, password: string) => {
    const query = "select * from profesor where correo = ? and contraseña = ?"

    return new Promise<Profesor | null>((resolve, reject) => {
        db.query(query, [email, password], (err, rows, fields) => {
            if (err || !rows[0]) {
                return resolve(null)
            }

            const profesor: Profesor = {
                id: rows[0]?.id_profesor ?? 0,
                nombre: rows[0]?.nombre ?? '',
                apellido: rows[0]?.apellidos ?? '',
                password: rows[0]?.password ?? '',
                correo: rows[0]?.correo ?? ''
            }

            return resolve(profesor)
        })
    })
}

export = { loginAlumno, loginProfesor }