import { Actividad } from '../data/entity/actividad'
import { Alumno } from '../data/entity/alumno'
import { Empresa } from '../data/entity/empresa'
import { Profesor } from '../data/entity/profesor'
import db from '../db'

const getAll = async (id: number) => {
    const query = "select * from alumno where id_profesor = ?"
    return new Promise<Array<Alumno>>((resolve, rejects) => {
        db.query(query, [id], (err, rows, fields) => {
            if (err) {
                return resolve([])
            }

            const result: Array<Alumno> = rows.map(el => {
                return {
                    id: el?.id_alumno ?? 0,
                    nombre: el?.nombre ?? '',
                    apellidos: el?.apellidos ?? '',
                    password: el?.password ?? '',
                    dni: el?.DNI ?? '',
                    fechaN: el?.fechaN ?? '',
                    correo: el?.correo ?? '',
                    tel: el?.telefono ?? '',
                    empresa: el?.id_empresa ?? 0,
                    tutor: el?.id_profesor ?? 0,
                    observaciones: el?.observaciones ?? '',
                    horasDual: el?.horasDual ?? 0,
                    horasFCT: el?.horasFCT ?? 0
                }
            })

            return resolve(result)
        })
    })
}

const insert = async (alumno: Alumno) => {
    const query = "insert into alumno values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
    return new Promise<boolean>((resolve, rejects) => {
        db.query(query, [
            null,
            alumno.nombre,
            alumno.apellidos,
            alumno.password,
            alumno.dni,
            alumno.fechaN,
            alumno.correo,
            alumno.tel,
            alumno.empresa,
            alumno.tutor,
            alumno.observaciones,
            alumno.horasDual,
            alumno.horasFCT
        ], (err, rows, fields) => {
            if (err) {
                return resolve(false)
            }

            return resolve(true)
        })
    })
}

const getById = async (id: number) => {
    const query = "select * from alumno where id_alumno = ?"
    return new Promise<Alumno | null>((resolve, reject) => {
        db.query(query, [id], (err, rows, fields) => {
            if (err || !rows[0])
                return resolve(null)

            const alumno: Alumno = {
                id: rows[0]?.id_alumno ?? 0,
                nombre: rows[0]?.nombre ?? '',
                apellidos: rows[0]?.apellidos ?? '',
                password: rows[0]?.password ?? '',
                dni: rows[0]?.DNI ?? '',
                fechaN: rows[0].fechaN ?? '',
                correo: rows[0].correo ?? '',
                tel: rows[0].telefono ?? '',
                empresa: rows[0].id_empresa ?? 0,
                tutor: rows[0].id_profesor ?? 0,
                observaciones: rows[0].observaciones ?? '',
                horasDual: rows[0].horasDual ?? 0,
                horasFCT: rows[0].horasFCT ?? 0
            }

            return resolve(alumno)
        })
    })
}

const getAllActividades = (id: number) => {
    const query = "select * from tarea where id_alumno = ?"

    return new Promise<Array<Actividad>>((resolve, _) => {
        db.query(query, [id], (err, rows, fields) => {
            if (err) {
                return resolve([])
            }

            const result: Array<Actividad> = rows.map(el => {
                return {
                    id: el?.id_tarea ?? 0,
                    fecha: el?.fecha ?? "",
                    tipo: el?.tipo ?? "",
                    totalHoras: el?.totalHoras ?? 0,
                    actividad: el?.actividad ?? "",
                    observaciones: el?.observaciones ?? ""
                }
            })

            return resolve(result)
        })
    })
}

const getProfesor = (id: number) => {
    const query = "select * from profesor where id_profesor = ?"

    return new Promise<Profesor | null>((resolve, _) => {
        db.query(query, [id], (err, rows, fields) => {
            if (err || !rows[0]) {
                return resolve(null)
            }

            const profesor: Profesor = {
                id: rows[0]?.id_profesor ?? 0,
                nombre: rows[0]?.nombre ?? '',
                apellido: rows[0]?.apellidos ?? '',
                password: rows[0]?.password ?? '',
                correo: rows[0]?.correo ?? ''
            }

            return resolve(profesor)
        })
    })
}

const getEmpresa = (id: number) => {
    const query = "select * from empresa where id_empresa = ?"

    return new Promise<Empresa | null>((resolve, _) => {
        db.query(query, [id], (err, rows, fields) => {
            if (err || !rows[0]) {
                return resolve(null)
            }

            const empresa: Empresa = {
                id: rows[0]?.id_empresa ?? 0,
                nombre: rows[0]?.id_empresa ?? '',
                tel: rows[0]?.telefono ?? '',
                correo: rows[0]?.correo ?? '',
                responsable: rows[0]?.responsable ?? '',
                observaciones: rows[0]?.observaciones ?? ''
            }

            return resolve(empresa)
        })
    })
}

const getHoras = async (id: number) => {
    const alumno = await getById(id)

    if (!alumno) return null

    return {
        horasDual: alumno?.horasDual ?? 0,
        horasFCT: alumno?.horasFCT ?? 0
    }
}

const update = async (id: number, newAlumno: Alumno) => {

    const query = "update alumno set nombre = ?, apellidos = ?, contraseña = ?, DNI = ?, fechaN = ?, correo = ?, telefono = ?, id_empresa = ?, id_profesor = ?, observaciones = ?, horasDual = ?, horasFCT = ? where id_alumno = ?"

    return new Promise<boolean>((resolve, reject) => {
        db.query(query, [
            newAlumno.nombre,
            newAlumno.apellidos,
            newAlumno.password,
            newAlumno.dni,
            newAlumno.fechaN,
            newAlumno.correo,
            newAlumno.tel,
            newAlumno.empresa,
            newAlumno.tutor,
            newAlumno.observaciones,
            newAlumno.horasDual,
            newAlumno.horasFCT,
            id
        ], (err, rows, fields) => {
            if (err) {
                return resolve(false)
            }

            return resolve(true)
        })
    })
}

const remove = async (id: number) => {
    const query = "delete from alumno where id_alumno = ?"
    return new Promise<boolean>((resolve, reject) => {
        db.query(query, [id], (err, rows, fields) => {
            if (err) {
                return resolve(false)
            }

            return resolve(true)
        })
    })
}
export const alumno = { getById, getAllActividades, getProfesor, getEmpresa, getHoras, getAll, insert, remove, update }
