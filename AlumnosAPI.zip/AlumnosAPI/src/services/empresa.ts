import { rejects } from 'assert'
import { resolve } from 'path'
import { Empresa } from '../data/entity/empresa'
import debug from 'debug'
import db from '../db'

const log = debug("app:empresas")
const getAll = async () => {
    const query = "select * from empresa"

    return new Promise<Array<Empresa>>((resolve, rejects) => {
        db.query(query, (err, rows, fields) => {
            if (err) {
                return resolve([])
            }

            const result: Array<Empresa> = rows.map(el => {
                return {
                    id: el?.id_empresa,
                    nombre: el?.nombre,
                    tel: el?.telefono,
                    correo: el?.correo,
                    responsable: el?.responsable,
                    observaciones: el?.observaciones
                }
            })

            return resolve(result)
        })
    })
}

const insert = async (empresa: Empresa) => {
    return new Promise<boolean>((resolve, rejects) => {
        const query = "insert into empresa values (?,?,?,?,?,?)"

        db.query(query, [
            null,
            empresa.nombre,
            empresa.tel,
            empresa.correo,
            empresa.responsable,
            empresa.observaciones
        ], (err, rows, fields) => {
            if (err) {
                return resolve(false)
            }

            resolve(true)

        })
    })
}

const update = async (id: number, newEmpresa: Empresa) => {
    return new Promise<boolean>((resolve, rejects) => {
        const query = "update empresa set nombre = ?, telefono = ?, correo = ?, responsable = ?, observaciones = ? where id_empresa = ?"

        db.query(query, [
            newEmpresa.nombre,
            newEmpresa.tel,
            newEmpresa.correo,
            newEmpresa.responsable,
            newEmpresa.observaciones,
            id
        ], (err, rows, fields) => {
            if (err) {
                log(err)
                return resolve(false)
            }

            resolve(true)
        })

    })
}

const remove = async (id: number) => {
    return new Promise<boolean>((resolve, rejects) => {
        const query = "delete from empresa where id_empresa = ?"

        db.query(query, [id], (err, rows, fields) => {
            if (err) {
                log(err)
                return resolve(false)
            }

            resolve(true)

        })
    })
}
export const empresa = { getAll, insert, update, remove }