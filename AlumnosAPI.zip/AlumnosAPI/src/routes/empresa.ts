import express from "express"
import { empresa } from "../controllers"

const router = express.Router()

router
    .get('/', empresa.getAll) // Get All empresa
    .post('/', empresa.insert) // POST empresa
    .put('/:id', empresa.update) // PUT empresa
    .delete('/:id', empresa.remove) // DELETE empresa

export = { router }