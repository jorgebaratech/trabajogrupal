import express from "express"
import { actividad } from "../controllers"

const router = express.Router()

router
    .get('/', actividad.getAll) // GET all
    .post('/', actividad.insert) // Post new actividad
    .get('/:id', actividad.getById) // Get By Id
    .put('/:id', actividad.update) // Update by id
    .delete('/:id', actividad.remove) // Remove by id

export = { router }