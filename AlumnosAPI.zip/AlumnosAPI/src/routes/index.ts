import actividad from "./actividad"
import alumno from "./alumno"
import login from "./login"
import empresa from "./empresa"

const routes = {
    actividad, alumno, login, empresa
}

export = routes 