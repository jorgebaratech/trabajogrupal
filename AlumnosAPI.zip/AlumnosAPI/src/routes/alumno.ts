import express from "express"
import { alumno } from "../controllers"

const router = express.Router()

router
    .get('/', alumno.getAll) // Get All alumnos
    .post('/', alumno.insert) // POST Alumno
    .delete('/:id', alumno.remove) // DELETE Alumno
    .put('/:id', alumno.update)
    .get('/actividades/:id', alumno.getAllActividades) // Get By Id
    .get('/empresa/:id', alumno.getEmpresa) // Get empresa
    .get('/profesor/:id', alumno.getProfesor) // Get profesor
    .get('/horas/:id', alumno.getHoras) // Get horas
    .get('/:id', alumno.getById) // Get By Id

export = { router }