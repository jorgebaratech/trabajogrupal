import express from "express"
import { login } from "../controllers"

const router = express.Router()

router
    .post('/alumno', login.loginAlumno) // Login app
    .post('/profesor', login.loginProfesor) // Login app

export = { router }