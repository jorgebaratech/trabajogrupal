import mysql from 'mysql'
import debug from 'debug'


const log = debug('app:MysqlConnection')

const conex = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'practicas'
})

conex.connect((err) => log(err ? `Something went wrong to connect DB -> ${err}` : "DB connected successful"))

export = conex