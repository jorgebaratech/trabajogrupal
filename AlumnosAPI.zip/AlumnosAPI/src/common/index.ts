import { HttpError, InternalServerError } from "http-errors"
import express from "express"


const success = (response: express.Response, status = 200, body: object | Array<object> = {}) => response.status(status).send(body)


const fail = (response: express.Response, error: HttpError | null = null) => {
    const { statusCode, message } = error ? error : new InternalServerError()

    response.status(statusCode).json({ message })
}

export const res = { success, fail }