import actividad from './actividad'
import alumno from './alumno'
import login from './login'
import empresa from './empresa'

const controllers = {
    actividad,
    alumno,
    login,
    empresa
}

export = controllers