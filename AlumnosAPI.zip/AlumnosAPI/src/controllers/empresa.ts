import express from "express"
import service from '../services'
import { res } from "../common"
import { NotFound, BadRequest } from "http-errors"
import debug from "debug"

const log = debug("app:empresas")


const getAll = async (request: express.Request, response: express.Response) => {

    const empresas = await service.empresa.getAll()

    return res.success(response, 200, empresas)
}


const insert = async (request: express.Request, response: express.Response) => {

    const { body: empresa } = request

    const inserted = await service.empresa.insert(empresa)

    if (!inserted) {
        return res.fail(response, BadRequest())
    }

    return res.success(response, 200, { success: true })
}

const update = async (request: express.Request, response: express.Response) => {

    const { params: { id }, body: empresa } = request

    const updated = await service.empresa.update(Number(id), empresa)

    if (!updated) {
        return res.fail(response, BadRequest())
    }

    return res.success(response, 200, { success: true })
}

const remove = async (request: express.Request, response: express.Response) => {

    const { params: { id } } = request

    const deleted = await service.empresa.remove(Number(id))

    if (!deleted) {
        return res.fail(response, BadRequest())
    }

    return res.success(response, 200, { success: true })
}

const empresa = { getAll, insert, update, remove }
export = empresa