import express from "express"
import service from '../services'
import { res } from "../common"
import { NotFound, BadRequest } from "http-errors"


const getAll = async (request: express.Request, response: express.Response) => {
    const { query: { profesor } } = request

    if (!profesor) {
        return res.fail(response, BadRequest("Debes de indicar el id de un profesor"))
    }

    const alumnos = await service.alumno.getAll(Number(profesor))

    return res.success(response, 200, alumnos)
}

const insert = async (request: express.Request, response: express.Response) => {

    const { body: alumno } = request

    const inserted = await service.alumno.insert(alumno)

    if (!inserted) {
        return res.fail(response, BadRequest())
    }

    return res.success(response, 200, { success: true })
}

const getById = async (request: express.Request, response: express.Response) => {
    const { params: { id } } = request

    const alumno = await service.alumno.getById(Number(id))

    if (!alumno) {
        return res.fail(response, NotFound())
    }

    return res.success(response, 200, alumno)
}

const getAllActividades = async (request: express.Request, response: express.Response) => {
    const { params: { id } } = request

    const tareas = await service.alumno.getAllActividades(Number(id))

    return res.success(response, 200, tareas)
}

const getEmpresa = async (request: express.Request, response: express.Response) => {
    const { params: { id } } = request

    const empresa = await service.alumno.getEmpresa(Number(id))

    if (!empresa) {
        return res.fail(response, NotFound())
    }

    return res.success(response, 200, empresa)
}

const getProfesor = async (request: express.Request, response: express.Response) => {
    const { params: { id } } = request

    const profesor = await service.alumno.getProfesor(Number(id))

    if (!profesor) {
        return res.fail(response, NotFound())
    }

    return res.success(response, 200, profesor)
}

const getHoras = async (request: express.Request, response: express.Response) => {
    const { params: { id } } = request

    const horas = await service.alumno.getHoras(Number(id))

    if (!horas) {
        return res.fail(response, NotFound())
    }

    return res.success(response, 200, horas)
}

const update = async (request: express.Request, response: express.Response) => {
    const { params: { id }, body: alumno } = request

    const updated = service.alumno.update(Number(id), alumno)

    if (!updated) {
        return res.fail(response, BadRequest("Alumno no puede ser eliminado"))
    }

    return res.success(response, 200, { success: updated })
}

const remove = async (request: express.Request, response: express.Response) => {
    const { params: { id } } = request

    const deleted = service.alumno.remove(Number(id))

    if (!deleted) {
        return res.fail(response, BadRequest("Alumno no puede ser eliminado"))
    }

    return res.success(response, 200, { success: deleted })
}

const alumno = { getById, getAllActividades, getEmpresa, getHoras, getProfesor, getAll, insert, remove, update }
export = alumno