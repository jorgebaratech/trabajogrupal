import { Alumno } from '../data/entity/alumno'
import { Profesor } from '../data/entity/profesor'
import service from '../services'
import express from 'express'
import debug from 'debug'
import { res } from '../common'
import { NotFound } from 'http-errors'

const log = debug("app:Login")

const loginAlumno = async (request: express.Request, response: express.Response) => {
    const { body: { email, password } } = request

    const user = await service.login.loginAlumno(email, password)

    if (!user) {
        return res.fail(response, NotFound())
    }

    return res.success(response, 200, user)
}

const loginProfesor = async (request: express.Request, response: express.Response) => {
    const { body: { email, password } } = request

    const user = await service.login.loginProfesor(email, password)

    if (!user) {
        return res.fail(response, NotFound())
    }

    return res.success(response, 200, user)
}

export = { loginAlumno, loginProfesor }