import express from "express"
import service from "../services"
import { res } from "../common"
import debug from "debug"
import { NotFound, BadRequest } from "http-errors"

const log = debug("app:Actividad")

const getAll = async (request: express.Request, response: express.Response) => {

    const actividades = await service.actividad.getAll()

    if (!actividades) {
        res.fail(response, NotFound())
    }

    return res.success(response, 200, actividades)
}

const getById = async (request: express.Request, response: express.Response) => {
    const { params: { id } } = request

    const actividad = await service.actividad.getById(Number(id))

    if (!actividad) {
        return res.fail(response, NotFound())
    }

    return res.success(response, 200, actividad)
}

const insert = async (request: express.Request, response: express.Response) => {

    const { body } = request

    const inserted = await service.actividad.insert(body)

    if (!inserted) {
        return res.fail(response, BadRequest())
    }

    return res.success(response, 200, { success: true })
}

const update = async (request: express.Request, response: express.Response) => {
    const { body, params: { id } } = request

    const numberId = Number(id)
    const actividad = { id: numberId, ...body }

    const updated = await service.actividad.update(actividad)

    log(actividad)

    if (!updated) {
        return res.fail(response, BadRequest())
    }

    return res.success(response, 200, { success: true })

}

const remove = async (request: express.Request, response: express.Response) => {
    const { params: { id } } = request

    const deleted = await service.actividad.remove(Number(id))

    if (!deleted) {
        return res.fail(response, BadRequest())
    }

    return res.success(response, 200, { success: true })
}

const actividad = { getById, insert, update, remove, getAll }
export = actividad