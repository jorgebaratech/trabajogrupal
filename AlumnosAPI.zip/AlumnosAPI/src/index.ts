import express from "express"
import cors from "cors"
import debug from "debug"
import routers from "./routes"

const app = express()
const log = debug("app:index")

const HOST = "localhost"
const PORT = 3000
const URL = `${HOST}:${PORT}`

app.use(cors())
app.options("*", cors())

//middleware
app.use(express.json())


// Routes
app.use(`/actividades`, routers.actividad.router)
app.use(`/alumnos`, routers.alumno.router)
app.use('/empresas', routers.empresa.router)
app.use('/login', routers.login.router)


app.listen(PORT, () => {
    log(`Server is running on ${URL}`)
})