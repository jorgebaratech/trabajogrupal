import { Alumno } from "./alumno";

export interface Actividad {
    id: number,
    fecha: string,
    tipo: string,
    totalHoras: number,
    actividad: string,
    observaciones: string,
    id_alumno?: number
}