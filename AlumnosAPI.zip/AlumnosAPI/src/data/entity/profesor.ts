export interface Profesor {
    id: number,
    nombre: string,
    apellido: string,
    password: string,
    correo: string

}