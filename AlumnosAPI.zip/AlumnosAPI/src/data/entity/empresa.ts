export interface Empresa {
    id: number,
    nombre: string,
    tel: string,
    correo: string,
    responsable: string,
    observaciones: string
}