export interface Alumno {
    id: number,
    nombre: string,
    apellidos: string,
    password: string,
    dni: string,
    fechaN: string,
    correo: string,
    tel: string,
    empresa: number,
    tutor: number,
    observaciones: string,
    horasDual: number,
    horasFCT: number
}